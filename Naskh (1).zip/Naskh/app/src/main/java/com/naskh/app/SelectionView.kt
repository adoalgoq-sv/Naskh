package com.naskh.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** Frozen screenshot + drag-to-select rectangle. */
class SelectionView(
    ctx: Context,
    private val shot: Bitmap,
    private val onSelected: (Bitmap?) -> Unit
) : View(ctx) {

    private var x0 = 0f; private var y0 = 0f; private var x1 = 0f; private var y1 = 0f
    private var dragging = false

    private val dim = Paint().apply { color = 0x88000000.toInt() }
    private val border = Paint().apply {
        color = Color.CYAN; style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true
    }
    private val clear = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }

    private fun sel() = RectF(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1))

    override fun onDraw(c: Canvas) {
        c.drawBitmap(shot, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        if (dragging || (x1 != x0 && y1 != y0)) {
            val r = sel()
            c.save(); c.clipRect(r)
            c.drawBitmap(shot, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), null)
            c.restore()
            c.drawRect(r, border)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y; dragging = true }
            MotionEvent.ACTION_MOVE -> { x1 = e.x; y1 = e.y }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val r = sel()
                if (r.width() < 20 || r.height() < 20) { onSelected(null); return true }
                val sx = shot.width / width.toFloat()
                val sy = shot.height / height.toFloat()
                val l = (r.left * sx).toInt().coerceIn(0, shot.width - 1)
                val t = (r.top * sy).toInt().coerceIn(0, shot.height - 1)
                val w = (r.width() * sx).toInt().coerceAtMost(shot.width - l).coerceAtLeast(1)
                val h = (r.height() * sy).toInt().coerceAtMost(shot.height - t).coerceAtLeast(1)
                onSelected(Bitmap.createBitmap(shot, l, t, w, h))
                return true
            }
        }
        invalidate()
        return true
    }
}
