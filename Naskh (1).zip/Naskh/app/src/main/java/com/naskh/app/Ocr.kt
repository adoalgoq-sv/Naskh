package com.naskh.app

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

object Ocr {
    private var api: TessBaseAPI? = null

    private fun ensure(ctx: Context): TessBaseAPI {
        api?.let { return it }
        val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
        for (name in listOf("ara.traineddata", "eng.traineddata")) {
            val f = File(dir, name)
            if (!f.exists() || f.length() < 1000) {
                runCatching {
                    val url = java.net.URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$name")
                    val tmp = File(dir, "$name.tmp")
                    url.openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
            }
        }
        val langs = listOf("ara", "eng").filter { File(dir, "$it.traineddata").exists() }.joinToString("+")
        val t = TessBaseAPI()
        t.init(ctx.filesDir.absolutePath, langs.ifEmpty { "ara" })
        api = t
        return t
    }

    @Synchronized
    fun read(ctx: Context, bmp: Bitmap): String {
        val t = ensure(ctx)
        t.setImage(bmp)
        return t.utF8Text.orEmpty().trim()
    }
}
