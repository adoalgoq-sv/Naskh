package com.naskh.app

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import kotlin.concurrent.thread

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_CAPTURE = "capture"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "naskh"
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: SelectionView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_CAPTURE -> main.postDelayed({ capture() }, 450) // let the shade close
            ACTION_STOP -> { cleanup(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        startForeground(1, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { cleanup(); stopSelf() }
            }, main)
        }

        val m = resources.displayMetrics
        reader = ImageReader.newInstance(m.widthPixels, m.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "naskh", m.widthPixels, m.heightPixels, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
    }

    private fun capture() {
        if (overlay != null) return
        val img = reader?.acquireLatestImage() ?: run { toast("جرّب مرة ثانية"); return }
        val shot: Bitmap
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * img.width
            val full = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            shot = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        } finally { img.close() }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        overlay = SelectionView(this, shot) { crop ->
            overlay?.let { wm.removeView(it) }
            overlay = null
            if (crop != null) recognize(crop)
        }
        wm.addView(overlay, lp)
    }

    private fun recognize(bmp: Bitmap) {
        toast("جاري القراءة...")
        thread {
            val text = runCatching { Ocr.read(this, bmp) }.getOrDefault("")
            main.post {
                if (text.isBlank()) toast("ما لقيت نص")
                else {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("naskh", text))
                    toast("تم النسخ")
                }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "ناسخ", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, rc: Int) = PendingIntent.getService(
            this, rc, Intent(this, CaptureService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_crop)
            .setContentTitle("ناسخ")
            .setContentText("اضغط «نسخ» لتحديد النص")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "نسخ", pi(ACTION_CAPTURE, 1)).build())
            .addAction(Notification.Action.Builder(null, "إيقاف", pi(ACTION_STOP, 2)).build())
            .build()
    }

    private fun cleanup() {
        overlay?.let { runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } }
        overlay = null
        display?.release(); reader?.close(); projection?.stop()
        display = null; reader = null; projection = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}
